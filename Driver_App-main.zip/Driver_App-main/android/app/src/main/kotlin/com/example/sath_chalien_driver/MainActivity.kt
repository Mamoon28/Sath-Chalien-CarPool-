package com.example.sath_chalien_driver

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
